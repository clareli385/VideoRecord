package com.example.clareli.mvp_video_record.Model;

import com.example.clareli.mvp_video_record.View.AutoFitTextureView;

public interface IVideoRecord {
    void updatePreview();
    void setAudioSource(int micSource);
    void setVideoSource(int surface);
    void setVideoOutputFormat(int outputFormat); //MediaRecorder.OutputFormat.MPEG_4
    void setVideoOutputFile(String outputPath);
    void setVideoEncodingBitRate(int rate);
    void setVideoFrameRate(int rate); //rate = 30 or 60
    void setVideoSize(int width, int height);
    void setVideoEncoder(int videoEncoder); //MediaRecorder.VideoEncoder.H264
    void setAudioEncoder(int audioEncoder); //MediaRecorder.AudioEncoder.AAC
    void setupVideoRecord();
    void startPreview();
    void startRecordingVideo(String filePath);
    void stopRecordingVideo();
    void openCamera(int width, int height);
    void closeCamera();
    void setSurfaceTextureListener();
    void configureTransform(int viewWidth, int viewHeight);
    void setCameraStateCallback();
    void checkTextureViewListener(AutoFitTextureView textureView);
    void closePreviewSession();
}
