package com.example.clareli.mvp_video_record.Presenter;

import android.app.Activity;

import com.example.clareli.mvp_video_record.View.AutoFitTextureView;

public interface IPresenterVideoPreviewRecord {
    void videoRecordStart(String filePath);
    void videoRecordStop();
    void videoPreview(AutoFitTextureView textureView);
    void closeCamera();
    void cameraOpenError();
    int getDisplayRotation();
    boolean isFinish();
    Object getSystemService();
    int getConfigurationOrientation();
//    void videoRecordInit(Activity activity, int width, int height);
}
