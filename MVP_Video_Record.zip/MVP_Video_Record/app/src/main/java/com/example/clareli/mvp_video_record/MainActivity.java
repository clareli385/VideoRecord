package com.example.clareli.mvp_video_record;

import android.content.pm.PackageManager;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.clareli.mvp_video_record.Presenter.IPresenterVideoPreviewRecord;
import com.example.clareli.mvp_video_record.Presenter.PresenterVideoPreviewRecord;
import com.example.clareli.mvp_video_record.View.AutoFitTextureView;

import java.io.File;

import static android.Manifest.permission.CAMERA;
import static android.Manifest.permission.RECORD_AUDIO;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;
import static com.example.clareli.mvp_video_record.Util.IConstant.REQUEST_PERMISSION_CODE;

public class MainActivity extends AppCompatActivity {
    private AutoFitTextureView mTextureView = null;
    private Button recordStartBtn, recordStopBtn;
    private IPresenterVideoPreviewRecord iPresenterVideoPreviewRecord = null;
    private static String _fileName = "my_record.mp4";
    private String _filePath = null;
    private File _fileAudio = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findViews();

        if(checkPermission()) {
            initPresenter();
        } else {
            requestPermission();
        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        if(mTextureView.isAvailable())
            iPresenterVideoPreviewRecord.videoPreview(mTextureView);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if(iPresenterVideoPreviewRecord != null)
            iPresenterVideoPreviewRecord.closeCamera();
    }

    public void findViews(){
        mTextureView = findViewById(R.id.texture);
        recordStartBtn = findViewById(R.id.video_record_start);
        recordStopBtn = findViewById(R.id.video_record_stop);
        recordStartBtn.setOnClickListener(recordClickListener);
        recordStopBtn.setOnClickListener(recordClickListener);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.KITKAT) {
            //save to internal storage D
            _filePath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath();
            _fileAudio = new File(_filePath, _fileName);
        }
    }

    public void initPresenter(){
        iPresenterVideoPreviewRecord = new PresenterVideoPreviewRecord(this, mTextureView.getWidth(), mTextureView.getHeight());

    }

    View.OnClickListener recordClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.video_record_start:
                    iPresenterVideoPreviewRecord.videoRecordStart(_fileAudio.getAbsolutePath());
                    break;
                case R.id.video_record_stop:
                    iPresenterVideoPreviewRecord.videoRecordStop();
            }
        }
    };




    public boolean checkPermission() {
        int result = ContextCompat.checkSelfPermission(getApplicationContext(),
                WRITE_EXTERNAL_STORAGE);
        int result1 = ContextCompat.checkSelfPermission(getApplicationContext(),
                RECORD_AUDIO);
        int result2 = ContextCompat.checkSelfPermission(getApplicationContext(),
                CAMERA);
        return result == PackageManager.PERMISSION_GRANTED &&
                result1 == PackageManager.PERMISSION_GRANTED &&
                result2 == PackageManager.PERMISSION_GRANTED;
    }

    private void requestPermission() {
        ActivityCompat.requestPermissions(MainActivity.this, new
                String[]{WRITE_EXTERNAL_STORAGE, RECORD_AUDIO, CAMERA}, REQUEST_PERMISSION_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == REQUEST_PERMISSION_CODE){
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                // permission was granted, yay!
                initPresenter();
            } else {
                finish();
                // permission denied, boo!
            }
        }
    }

}
