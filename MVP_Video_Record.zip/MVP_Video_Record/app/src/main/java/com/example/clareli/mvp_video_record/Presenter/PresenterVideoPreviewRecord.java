package com.example.clareli.mvp_video_record.Presenter;

import android.app.Activity;
import android.content.Context;

import com.example.clareli.mvp_video_record.Model.IVideoRecord;
import com.example.clareli.mvp_video_record.Model.VideoRecordClass;
import com.example.clareli.mvp_video_record.View.AutoFitTextureView;

import java.lang.ref.WeakReference;

public class PresenterVideoPreviewRecord implements IPresenterVideoPreviewRecord {
    private final WeakReference<Activity> _messageViewReference;
    private int textureViewWidth = 0, textureViewHeight = 0;
    private IVideoRecord iVideoRecord;

    public PresenterVideoPreviewRecord(Activity activity, int width, int height){
        _messageViewReference = new WeakReference<>(activity);
        textureViewWidth = width;
        textureViewHeight = height;
        iVideoRecord = new VideoRecordClass(_messageViewReference.get(), width, height, this);

    }
    @Override
    public void videoRecordStart(String filePath) {
        iVideoRecord.startRecordingVideo(filePath);
    }

    @Override
    public void videoRecordStop() {
        iVideoRecord.stopRecordingVideo();
    }

    @Override
    public void videoPreview(AutoFitTextureView textureView) {
        iVideoRecord.setSurfaceTextureListener();
        iVideoRecord.checkTextureViewListener(textureView);

    }

    @Override
    public void closeCamera() {
        iVideoRecord.closeCamera();
    }

    @Override
    public void cameraOpenError() {
        _messageViewReference.get().finish();
    }

    @Override
    public int getDisplayRotation() {
        int rotation = _messageViewReference.get().getWindowManager().getDefaultDisplay().getRotation();
        return rotation;
    }

    @Override
    public boolean isFinish() {
        return _messageViewReference.get().isFinishing();

    }

    @Override
    public Object getSystemService() {
        return _messageViewReference.get().getSystemService(Context.CAMERA_SERVICE);
    }

    @Override
    public int getConfigurationOrientation() {
        return _messageViewReference.get().getResources().getConfiguration().orientation;
    }

}
