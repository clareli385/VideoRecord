package com.example.clareli.mvp_video_record.Util;

public interface IConstant {
    int REQUEST_PERMISSION_CODE = 0x20FF;
    int COMPLETE_RESULT = 100;
    int FAIL_RESULT = -1;

}
